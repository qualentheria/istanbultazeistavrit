// Sepet yönetimi
let cart = [];
let cartModal = document.getElementById('cartModal');
let cartIcon = document.querySelector('.cart-icon');
let closeModal = document.querySelector('.close');
let cartBadge = document.querySelector('.cart-icon-badge');

// Hamburger menü
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    
    // Hamburger animasyonu
    const spans = hamburger.querySelectorAll('span');
    if (navMenu.classList.contains('active')) {
        spans[0].style.transform = 'rotate(-45deg) translate(-5px, 6px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(45deg) translate(-5px, -6px)';
    } else {
        spans[0].style.transform = '';
        spans[1].style.opacity = '1';
        spans[2].style.transform = '';
    }
});

// Navigasyon linkleri tıklandığında menüyü kapat
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        const spans = hamburger.querySelectorAll('span');
        spans[0].style.transform = '';
        spans[1].style.opacity = '1';
        spans[2].style.transform = '';
    });
});

// Smooth scroll navigasyon
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Sepete ürün ekleme
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const product = this.dataset.product;
        const price = parseFloat(this.dataset.price);
        const productName = this.parentElement.querySelector('h3').textContent;
        
        // Ürün zaten sepette var mı kontrol et
        const existingItem = cart.find(item => item.product === product);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                product: product,
                name: productName,
                price: price,
                quantity: 1
            });
        }
        
        updateCartBadge();
        showNotification('Ürün sepete eklendi!');
        
        // Buton animasyonu
        this.textContent = '✓ Eklendi';
        this.style.background = '#28a745';
        setTimeout(() => {
            this.textContent = 'Sepete Ekle';
            this.style.background = '';
        }, 1000);
    });
});

// Sepet sayısını güncelle
function updateCartBadge() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartBadge.textContent = totalItems;
}

// Sepeti göster
cartIcon.addEventListener('click', () => {
    displayCart();
    cartModal.style.display = 'block';
});

// Modal kapat
closeModal.addEventListener('click', () => {
    cartModal.style.display = 'none';
});

// Modal dışına tıklandığında kapat
window.addEventListener('click', (e) => {
    if (e.target === cartModal) {
        cartModal.style.display = 'none';
    }
});

// Sepet içeriğini göster
function displayCart() {
    const cartItems = document.getElementById('cartItems');
    const totalPrice = document.getElementById('totalPrice');
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: #666;">Sepetiniz boş</p>';
        totalPrice.textContent = '₺0.00';
        return;
    }
    
    let html = '';
    let total = 0;
    
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        html += `
            <div class="cart-item">
                <div>
                    <strong>${item.name}</strong><br>
                    <small>₺${item.price.toFixed(2)} x ${item.quantity}</small>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <button onclick="updateQuantity(${index}, -1)" style="padding: 5px 10px; border: 1px solid #ddd; background: white; cursor: pointer;">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="updateQuantity(${index}, 1)" style="padding: 5px 10px; border: 1px solid #ddd; background: white; cursor: pointer;">+</button>
                    <button onclick="removeFromCart(${index})" style="padding: 5px 10px; background: #dc3545; color: white; border: none; cursor: pointer; border-radius: 4px;">Sil</button>
                </div>
            </div>
        `;
    });
    
    cartItems.innerHTML = html;
    totalPrice.textContent = `₺${total.toFixed(2)}`;
}

// Sepet miktarını güncelle
function updateQuantity(index, change) {
    cart[index].quantity += change;
    
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    
    updateCartBadge();
    displayCart();
}

// Sepetten ürün sil
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartBadge();
    displayCart();
}

// Bildirim göster
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: #28a745;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        z-index: 3000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Animasyon stilleri ekle
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Sipariş tamamla
document.querySelector('.checkout-button').addEventListener('click', () => {
    if (cart.length === 0) {
        alert('Sepetiniz boş!');
        return;
    }
    
    alert('Siparişiniz alındı! En kısa sürede teslim edilecektir.');
    cart = [];
    updateCartBadge();
    displayCart();
    cartModal.style.display = 'none';
});

// İletişim formu
document.querySelector('.contact-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Form verilerini al
    const formData = new FormData(e.target);
    
    // Normalde burada form verilerini sunucuya gönderirsiniz
    console.log('Form gönderildi:', Object.fromEntries(formData));
    
    // Başarı mesajı göster
    showNotification('Mesajınız başarıyla gönderildi!');
    
    // Formu temizle
    e.target.reset();
});

// Hero CTA butonu
document.querySelector('.cta-button').addEventListener('click', () => {
    document.querySelector('#urunler').scrollIntoView({
        behavior: 'smooth'
    });
});

// Scroll animasyonları
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Animasyon eklenecek elementleri gözlemle
document.querySelectorAll('.feature-card, .product-card, .stat').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
});

// Navbar scroll efekti
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        navbar.style.background = 'linear-gradient(135deg, rgba(0, 119, 190, 0.95), rgba(0, 168, 204, 0.95))';
        navbar.style.backdropFilter = 'blur(10px)';
    } else {
        navbar.style.background = '';
        navbar.style.backdropFilter = '';
    }
    
    lastScroll = currentScroll;
});

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', () => {
    // Loading animasyonu
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});
